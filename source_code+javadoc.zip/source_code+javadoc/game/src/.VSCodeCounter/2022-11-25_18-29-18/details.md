# Details

Date : 2022-11-25 18:29:18

Directory c:\\Users\\kamil\\Desktop\\serious-game\\game\\src

Total : 15 files,  1640 codes, 121 comments, 305 blanks, all 2066 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [entity/Entity.java](/entity/Entity.java) | Java | 21 | 1 | 7 | 29 |
| [entity/Player.java](/entity/Player.java) | Java | 158 | 13 | 23 | 194 |
| [main/AssetSetter.java](/main/AssetSetter.java) | Java | 116 | 3 | 45 | 164 |
| [main/CollisionChecker.java](/main/CollisionChecker.java) | Java | 117 | 0 | 18 | 135 |
| [main/GamePanel.java](/main/GamePanel.java) | Java | 104 | 7 | 23 | 134 |
| [main/KeyHandler.java](/main/KeyHandler.java) | Java | 231 | 45 | 17 | 293 |
| [main/Main.java](/main/Main.java) | Java | 17 | 0 | 6 | 23 |
| [main/Score.java](/main/Score.java) | Java | 62 | 5 | 16 | 83 |
| [main/UI.java](/main/UI.java) | Java | 664 | 46 | 105 | 815 |
| [object/OBJ_Door.java](/object/OBJ_Door.java) | Java | 14 | 0 | 3 | 17 |
| [object/OBJ_Enemy.java](/object/OBJ_Enemy.java) | Java | 13 | 0 | 3 | 16 |
| [object/OBJ_Heart.java](/object/OBJ_Heart.java) | Java | 15 | 0 | 5 | 20 |
| [object/SuperObject.java](/object/SuperObject.java) | Java | 26 | 0 | 7 | 33 |
| [tile/Tile.java](/tile/Tile.java) | Java | 6 | 0 | 3 | 9 |
| [tile/TileManager.java](/tile/TileManager.java) | Java | 76 | 1 | 24 | 101 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)