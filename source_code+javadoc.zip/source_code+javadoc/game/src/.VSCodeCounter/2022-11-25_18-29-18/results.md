# Summary

Date : 2022-11-25 18:29:18

Directory c:\\Users\\kamil\\Desktop\\serious-game\\game\\src

Total : 15 files,  1640 codes, 121 comments, 305 blanks, all 2066 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 15 | 1,640 | 121 | 305 | 2,066 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 15 | 1,640 | 121 | 305 | 2,066 |
| entity | 2 | 179 | 14 | 30 | 223 |
| main | 7 | 1,311 | 106 | 230 | 1,647 |
| object | 4 | 68 | 0 | 18 | 86 |
| tile | 2 | 82 | 1 | 27 | 110 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)