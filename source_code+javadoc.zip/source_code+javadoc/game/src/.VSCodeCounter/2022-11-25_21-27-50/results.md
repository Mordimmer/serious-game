# Summary

Date : 2022-11-25 21:27:50

Directory c:\\Users\\kamil\\Desktop\\serious-game\\game\\src

Total : 15 files,  1640 codes, 137 comments, 300 blanks, all 2077 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 15 | 1,640 | 137 | 300 | 2,077 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 15 | 1,640 | 137 | 300 | 2,077 |
| entity | 2 | 179 | 17 | 30 | 226 |
| main | 7 | 1,311 | 116 | 225 | 1,652 |
| object | 4 | 68 | 0 | 18 | 86 |
| tile | 2 | 82 | 4 | 27 | 113 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)