# Diff Summary

Date : 2022-11-25 21:27:50

Directory c:\\Users\\kamil\\Desktop\\serious-game\\game\\src

Total : 7 files,  0 codes, 16 comments, -5 blanks, all 11 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 7 | 0 | 16 | -5 | 11 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 7 | 0 | 16 | -5 | 11 |
| entity | 1 | 0 | 3 | 0 | 3 |
| main | 5 | 0 | 10 | -5 | 5 |
| tile | 1 | 0 | 3 | 0 | 3 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)