# Details

Date : 2022-11-25 21:27:50

Directory c:\\Users\\kamil\\Desktop\\serious-game\\game\\src

Total : 15 files,  1640 codes, 137 comments, 300 blanks, all 2077 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [entity/Entity.java](/entity/Entity.java) | Java | 21 | 1 | 7 | 29 |
| [entity/Player.java](/entity/Player.java) | Java | 158 | 16 | 23 | 197 |
| [main/AssetSetter.java](/main/AssetSetter.java) | Java | 116 | 4 | 40 | 160 |
| [main/CollisionChecker.java](/main/CollisionChecker.java) | Java | 117 | 0 | 18 | 135 |
| [main/GamePanel.java](/main/GamePanel.java) | Java | 104 | 12 | 23 | 139 |
| [main/KeyHandler.java](/main/KeyHandler.java) | Java | 231 | 46 | 17 | 294 |
| [main/Main.java](/main/Main.java) | Java | 17 | 0 | 6 | 23 |
| [main/Score.java](/main/Score.java) | Java | 62 | 7 | 16 | 85 |
| [main/UI.java](/main/UI.java) | Java | 664 | 47 | 105 | 816 |
| [object/OBJ_Door.java](/object/OBJ_Door.java) | Java | 14 | 0 | 3 | 17 |
| [object/OBJ_Enemy.java](/object/OBJ_Enemy.java) | Java | 13 | 0 | 3 | 16 |
| [object/OBJ_Heart.java](/object/OBJ_Heart.java) | Java | 15 | 0 | 5 | 20 |
| [object/SuperObject.java](/object/SuperObject.java) | Java | 26 | 0 | 7 | 33 |
| [tile/Tile.java](/tile/Tile.java) | Java | 6 | 0 | 3 | 9 |
| [tile/TileManager.java](/tile/TileManager.java) | Java | 76 | 4 | 24 | 104 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)